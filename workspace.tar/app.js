/* ===== Foodlingo — логика прототипа ===== */

// ---------- Данные уроков ----------
const LESSONS = [
  {
    id:"sugar", icon:"🥤", title:"Сахар и напитки", desc:"Сколько сахара в популярных напитках?",
    steps:[
      {type:"info", emoji:"🥤", title:"Что в сладкой газировке?", text:"Многие сладкие напитки содержат много добавленного сахара. Вода и напитки без добавленного сахара — отличные варианты для повседневного питья."},
      {type:"quiz", q:"Сколько примерно кубиков сахара может быть в бутылке сладкой газировки 500 мл?", options:["1–2","5–6","10–12"], answer:2, explain:"В некоторых напитках такого объёма действительно около 10–12 кубиков сахара! Но точное количество зависит от напитка — проверяй этикетку 😉"},
      {type:"quiz", q:"Что помогает снизить количество сладких напитков без чувства запрета?", options:["Полностью отказаться от всего вкусного","Чередовать: сегодня сок, завтра вода с лимоном","Пить только энергетики"], answer:1, explain:"Осознанный выбор — не запреты, а баланс. Добавь воду с ягодами или лимоном, чтобы она была вкусной 🍋"},
    ]
  },
  {
    id:"fastfood", icon:"🍔", title:"Фастфуд", desc:"Осознанный выбор без запретов",
    steps:[
      {type:"info", emoji:"🍔", title:"Фастфуд — не враг", text:"Иногда поесть фастфуд — это нормально. Важно не чувство вины, а понимание, что ты выбираешь, и как часто это происходит."},
      {type:"quiz", q:"Какой подход к фастфуду самый здоровый?", options:["Никогда его не есть — это запрещено","Есть осознанно: редко, наслаждаясь, и уравновешивать разнообразной едой","Есть каждый день, но маленькими порциями"], answer:1, explain:"Запреты усиливают тягу. Осознанный выбор «редко и с удовольствием» работает лучше, чем чувство вины 💚"},
      {type:"quiz", q:"Что можно улучшить в заказе фастфуда?", options:["Добавить овощи: салат, помидоры, фрукты вместо части соуса","Ничего, всё уже одинаково","Выбрать самую большую картошку фри"], answer:0, explain:"Маленькие шаги работают: овощной гарнир, вода вместо газировки — и приём пищи стал сбалансированнее 🥗"},
    ]
  },
  {
    id:"plate", icon:"🥗", title:"Собираем тарелку", desc:"Разнообразный приём пищи",
    steps:[
      {type:"info", emoji:"🥗", title:"Правило тарелки", text:"Простая идея: половину тарелки — овощи и фрукты, четверть — белок (мясо, рыба, бобовые, яйца), четверть — гарнир (крупы, картофель)."},
      {type:"quiz", q:"Какую часть тарелки по «правилу тарелки» занимают овощи и фрукты?", options:["Около половины","Четверть","Практически ничего"], answer:0, explain:"Верно! 🥦 Половина тарелки — овощи и фрукты. Это делает приём пищи ярким, вкусным и сытным."},
      {type:"quiz", q:"Что является хорошим источником белка?", options:["Только мясо","Бобовые, яйца, рыба, творог и птица","Только протеиновые батончики"], answer:1, explain:"Белок есть в самой разной еде: чечевица, нут, йогурт, орехи — отличные варианты для любого стиля питания 🌱"},
    ]
  },
  {
    id:"habits", icon:"🧠", title:"Голод и привычки", desc:"Почему мы едим, когда скучно?",
    steps:[
      {type:"info", emoji:"🧠", title:"Голод или скука?", text:"Мы иногда едим не потому, что голодны, а из-за скуки, стресса или привычки. Это нормально — важно это замечать."},
      {type:"quiz", q:"«Тест яблока»: если не хочется даже яблоко, скорее всего…", options:["Это настоящий голод","Это эмоциональный голод или скука","Нужно срочно есть чипсы"], answer:1, explain:"Хитрый тест 😄 Настоящий голод примет и яблоко. Если нет — возможно, тебе скучно или грустно. Попробуй прогулку, звонок другу, игру."},
      {type:"quiz", q:"Что помогает есть осознанно?", options:["Есть перед экраном телефона","Замедлиться и спросить себя: «Я сейчас голоден?»","Пропускать завтрак, а потом наедаться ночью"], answer:1, explain:"Осознанность — суперсила 🦸 Замедлись, почувствуй вкус, убери телефон во время еды."},
    ]
  },
  {
    id:"water", icon:"💧", title:"Вода", desc:"Почему важно пить?",
    steps:[
      {type:"info", emoji:"💧", title:"Ты почти целиком из воды", text:"Тело человека примерно на 60% состоит из воды. Даже лёгкое обезвоживание снижает энергию и концентрацию на уроках."},
      {type:"quiz", q:"Какие признаки могут говорить о недостатке воды?", options:["Усталость, головная боль, плохая концентрация","Излишняя бодрость","Ничего из перечисленного"], answer:0, explain:"Верно! 🤯 Часто «хочу спать» на самом деле означает «хочу пить». Держи бутылку воды рядом."},
      {type:"quiz", q:"Лёгкий способ пить больше воды — это…", options:["Пить только когда сильно захочется","Носить бутылку с собой и добавлять ягоды/лимон","Заменить воду кофе"], answer:1, explain:"Вода с огурцом, мятой или клубникой — вкуснее и красивее 🍓 Плюс напоминание в виде бутылки работает отлично."},
    ]
  },
  {
    id:"shop", icon:"🏪", title:"Выбор в магазине", desc:"Как читать этикетки",
    steps:[
      {type:"info", emoji:"🏪", title:"Этикетка — твой друг", text:"Состав пишется по убыванию: первые ингредиенты — те, которых больше всего. Сахар может прятаться под десятками имён!"},
      {type:"quiz", q:"Если сахар стоит в начале списка ингредиентов, это значит…", options:["Сахара в продукте много","Сахара совсем мало","Это витамин C"], answer:0, explain:"Точно! 🕵️ Первые места в составе — самые важные. Сироп, мальтодекстрин, концентрат сока — тоже формы сахара."},
      {type:"quiz", q:"Покупка по списку помогает…", options:["Тратить больше на импульсные покупки","Меньше покупать лишнего и выбирать осознаннее","Никак"], answer:1, explain:"Список = щит от рекламы у кассы 🛡️ И ещё: голодным в магазин лучше не ходить — проверено наукой!"},
    ]
  },
];

const ACHIEVEMENTS = [
  {id:"first", icon:"🌱", name:"Первый шаг", check:s=>s.completed.length>=1},
  {id:"xp100", icon:"⚡", name:"100 XP", check:s=>s.totalXp>=100},
  {id:"streak3", icon:"🔥", name:"Серия 3", check:s=>s.streak>=3},
  {id:"half", icon:"🥈", name:"Половина пути", check:s=>s.completed.length>=3},
  {id:"master", icon:"👑", name:"Мастер питания", check:s=>s.completed.length>=6},
];

// ---------- Состояние (localStorage) ----------
const KEY="foodlingo-v1";
const today=()=>new Date().toISOString().slice(0,10);

let state = load();
function load(){
  let s;
  try{ s = JSON.parse(localStorage.getItem(KEY)); }catch(e){ s=null; }
  if(!s) s = {totalXp:0, completed:[], streak:0, lastDay:null, achievements:[], lives:3};
  return s;
}
function save(){ localStorage.setItem(KEY, JSON.stringify(state)); }

function levelOf(xp){ return Math.floor(xp/100)+1; }
function addStreak(){
  const t=today();
  if(state.lastDay===t) return;
  const y=new Date(Date.now()-864e5).toISOString().slice(0,10);
  state.streak = state.lastDay===y ? state.streak+1 : 1;
  state.lastDay=t;
}

// ---------- Навигация ----------
const $=id=>document.getElementById(id);
function show(name){
  document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));
  $("screen-"+name).classList.add("active");
}
document.querySelectorAll(".nav-btn").forEach(b=>b.addEventListener("click",()=>{
  show(b.dataset.screen);
  if(b.dataset.screen==="progress") renderProgress();
}));

// ---------- Главный экран ----------
function renderHome(){
  const done=state.completed.length, pct=Math.round(done/LESSONS.length*100);
  $("home-streak").textContent=state.streak;
  $("home-xp").textContent=state.totalXp;
  $("home-level").textContent=levelOf(state.totalXp);
  $("home-lives").textContent=state.lives;
  $("home-percent").textContent=pct+"%";
  $("home-progress").style.width=pct+"%";
  $("mascot-bubble").textContent = done===0
    ? "Привет! Я Фреди 🐸 Начнём с основ питания?"
    : done===LESSONS.length
      ? "Вау! Ты прошёл все уроки! 🏆 Ты настоящий мастер!"
      : `Круто! Пройдено ${done} из ${LESSONS.length} уроков. Так держать! 💪`;

  // карта уроков
  const map=$("lesson-map"); map.innerHTML="";
  LESSONS.forEach((l,i)=>{
    const isDone=state.completed.includes(l.id);
    const unlocked = i===0 || state.completed.includes(LESSONS[i-1].id);
    const isCurrent = !isDone && unlocked;
    const node=document.createElement("div");
    node.className="lesson-node"+(isDone?" done":isCurrent?" current":" locked");
    node.innerHTML=`
      <div class="node-icon">${isDone?"✅":l.icon}</div>
      <div class="node-info"><b>Урок ${i+1} — ${l.title}</b><span>${l.desc}</span></div>
      <div class="node-status">${isDone?"🟢":isCurrent?"🔵":"🔒"}</div>`;
    if(unlocked) node.addEventListener("click",()=>startLesson(i));
    map.appendChild(node);
  });

  const nextIdx=LESSONS.findIndex(l=>!state.completed.includes(l.id));
  const btn=$("btn-continue");
  if(nextIdx===-1){ btn.textContent="ВСЕ УРОКИ ПРОЙДЕНЫ 🎉"; btn.disabled=true; btn.style.opacity=.6;}
  else { btn.textContent="ПРОДОЛЖИТЬ УРОК ▶"; btn.disabled=false; btn.style.opacity=1;
         btn.onclick=()=>startLesson(nextIdx); }
}

// ---------- Урок / Викторина ----------
let cur={lesson:null, step:0, gained:0, lives:3, selected:null, answered:false};

function startLesson(idx){
  cur={lesson:LESSONS[idx], step:0, gained:0, lives:3, selected:null, answered:false};
  show("lesson");
  renderStep();
}
$("btn-quit").addEventListener("click",()=>{ show("home"); renderHome(); });

function renderStep(){
  const l=cur.lesson, total=l.steps.length;
  $("quiz-bar").style.width=(cur.step/total*100)+"%";
  $("quiz-lives").textContent="❤️".repeat(cur.lives)+"🖤".repeat(3-cur.lives);
  const step=l.steps[cur.step];
  const body=$("quiz-body"), foot=$("quiz-footer");
  cur.selected=null; cur.answered=false;

  if(step.type==="info"){
    body.innerHTML=`<div class="info-card">
      <div class="big-emoji">${step.emoji}</div>
      <h2>${step.title}</h2><p>${step.text}</p></div>`;
    foot.innerHTML=`<button class="btn btn-primary big" id="btn-next-step">ДАЛЕЕ ▶</button>`;
    $("btn-next-step").onclick=nextStep;
  } else {
    body.innerHTML=`<div class="question-text">${step.q}</div>
      <div class="options">${step.options.map((o,i)=>`<button class="option" data-i="${i}">${String.fromCharCode(65+i)}. ${o}</button>`).join("")}</div>`;
    foot.innerHTML="";
    body.querySelectorAll(".option").forEach(btn=>btn.addEventListener("click",()=>{
      if(cur.answered) return;
      cur.answered=true;
      const i=+btn.dataset.i, correct=i===step.answer;
      body.querySelectorAll(".option").forEach(b=>{
        const bi=+b.dataset.i;
        if(bi===step.answer) b.classList.add("correct");
        else if(bi===i) b.classList.add("wrong");
        b.style.pointerEvents="none";
      });
      if(correct){
        cur.gained+=10;
        toast("+10 XP ⭐");
      } else {
        cur.lives--;
        $("quiz-lives").textContent="❤️".repeat(Math.max(cur.lives,0))+"🖤".repeat(3-Math.max(cur.lives,0));
      }
      foot.innerHTML=`<div class="feedback ${correct?"ok":"bad"}">
        <h3>${correct?"🎉 Правильно!":"😅 Не совсем…"}</h3><p>${step.explain}</p></div>
        <button class="btn ${correct?"btn-primary":"btn-cor"} big" style="margin-top:12px" id="btn-next-step">${correct?"ПРОДОЛЖИТЬ ▶":"ПОНЯТНО ▶"}</button>`;
      $("btn-next-step").onclick=nextStep;
    }));
  }
}
function nextStep(){
  cur.step++;
  if(cur.lives<=0){ finishLesson(false); return; }
  if(cur.step>=cur.lesson.steps.length){ finishLesson(true); return; }
  renderStep();
}
function finishLesson(passed){
  const bonus=passed?20:0;
  const xp=cur.gained+bonus;
  state.totalXp+=xp;
  if(passed && !state.completed.includes(cur.lesson.id)){
    state.completed.push(cur.lesson.id);
    addStreak();
  }
  state.lives=3;
  // достижения
  ACHIEVEMENTS.forEach(a=>{
    if(!state.achievements.includes(a.id) && a.check({...state})) state.achievements.push(a.id);
  });
  save();
  $("result-title").textContent=passed?"Урок пройден! 🎉":"Жизни закончились 💔";
  $("result-text").textContent=passed
    ? (bonus?`Отличная работа! Бонус +${bonus} XP за завершение урока.`:"Хорошее начало — попробуй ещё раз!")
    : "Не страшно! Фреди верит в тебя — попробуй снова 🐸";
  $("xp-award").textContent="+"+xp+" XP ⭐";
  show("result");
}
$("btn-finish").addEventListener("click",()=>{ show("home"); renderHome(); });

// ---------- XP тост ----------
let toastTimer;
function toast(text){
  const t=$("xp-toast"); t.textContent=text; t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>t.classList.remove("show"),1200);
}

// ---------- Прогресс ----------
function renderProgress(){
  const lvl=levelOf(state.totalXp), into=state.totalXp%100;
  $("prog-level").textContent=lvl;
  $("level-ring").style.background=`conic-gradient(var(--green) ${into}%, #eee 0)`;
  $("prog-xp").textContent=state.totalXp+" XP";
  $("prog-next-level").textContent=`до уровня ${lvl+1}: ${100-into} XP`;
  $("prog-streak").textContent=state.streak;
  $("prog-lessons").textContent=state.completed.length+"/"+LESSONS.length;
  $("prog-total").textContent=state.totalXp;

  $("achievements").innerHTML=ACHIEVEMENTS.map(a=>{
    const got=state.achievements.includes(a.id);
    return `<div class="ach ${got?"":"locked"}"><div class="ach-icon">${a.icon}</div><span>${a.name}</span></div>`;
  }).join("");

  $("topics").innerHTML=LESSONS.map((l,i)=>{
    const done=state.completed.includes(l.id);
    const unlocked=i===0||state.completed.includes(LESSONS[i-1].id);
    return `<div class="topic ${unlocked?"":"locked"}">${l.icon} ${l.title}<span class="t-check">${done?"✔ изучено":unlocked?"в процессе":"🔒"}</span></div>`;
  }).join("");
}

$("btn-reset").addEventListener("click",()=>{
  if(confirm("Сбросить весь прогресс?")){
    localStorage.removeItem(KEY);
    state=load(); renderProgress(); renderHome();
  }
});

// ---------- Старт ----------
renderHome();
